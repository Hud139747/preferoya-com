PreferoYa.com — MVP

1. Ouvrir index.html pour tester le site localement.
2. Le site est statique: HTML + CSS + JavaScript.
3. Modifier les produits/prix dans index.html, dans const products.
4. Remplacer assets/logo.png si nécessaire.
5. Pour la mise en ligne, envoyer le dossier sur GitHub puis l'importer dans Vercel.
6. Ensuite connecter le domaine preferoya.com dans Vercel > Project Settings > Domains et suivre les instructions DNS.

IMPORTANT: les prix affichés sont des prix de référence et doivent être revérifiés avant publication commerciale.
